from setuptools import setup

setup(
    name ='jconsole',
    version = '0.1',
    description = 'jconsole',
    author = 'junostudio',
    author_email = None,
    license='MIT',
    url = 'https://github.com/junostudio3/jconsole',
    py_modules = ['worker'],
    packages=['jconsole']
)